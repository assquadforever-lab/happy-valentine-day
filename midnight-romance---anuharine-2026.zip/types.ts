
export type AppState = 'GATE' | 'GALLERY' | 'MAP' | 'LETTER';

export interface Secret {
  id: number;
  x: number;
  y: number;
  content: string;
}

export interface Compliment {
  id: number;
  text: string;
  glowColor: string;
}
