
import React from 'react';

const PageLetter: React.FC = () => {
  return (
    <div className="min-h-screen pt-24 pb-32 px-6 flex flex-col items-center">
      <h2 className="font-playfair text-[#ffd700] text-4xl md:text-6xl mb-12">The Infinite Letter</h2>
      
      <div className="w-full max-w-3xl glass p-8 md:p-16 rounded-[40px] relative border-[#ffd700]/20 shadow-[0_0_50px_rgba(255,215,0,0.05)]">
        {/* Neon Edge Decor */}
        <div className="absolute -top-4 -left-4 w-12 h-12 border-t-2 border-l-2 border-[#ffd700]" />
        <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-2 border-r-2 border-[#ffd700]" />

        <div className="space-y-8 font-montserrat text-white/80 leading-relaxed text-lg">
          <p className="font-sacramento text-4xl text-[#ffd700] mb-4">Dear Anuharine,</p>
          
          <p>
            As we stand in the glow of 2026, I find myself looking back at every spark that led us here. 
            They say the universe is expanding, but it feels small compared to the space you occupy in my mind.
          </p>
          
          <p>
            This midnight experience is a small testament to the mystery and beauty you bring into my life every day. 
            Like the bears that glow in the dark, you have a way of finding light in the most silent moments. 
            You are the quiet magic in the noise, the neon rose in a field of grey.
          </p>

          <p>
            I promise that in 2026 and every year that follows, I will be the one holding the map to our universe, 
            pointing out the stars we've yet to name. I'll be the one sliding in to give you a hug when the world 
            feels a little too large.
          </p>

          <div className="py-12 flex justify-center">
            <div className="w-24 h-px bg-gradient-to-r from-transparent via-[#ffd700] to-transparent" />
          </div>

          <p>
            Thank you for being my constant. For being the person who makes "forever" seem like too short of a time.
            You are my midnight romance, my sunrise hope, and my everything in between.
          </p>

          <p className="font-sacramento text-5xl text-[#ffd700] pt-8 text-right">
            Always yours, <br />
            Forever & Beyond
          </p>
        </div>
      </div>
    </div>
  );
};

export default PageLetter;
