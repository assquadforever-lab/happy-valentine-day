
import React, { useState } from 'react';
import { COLORS } from '../constants';

interface PageGateProps {
  onUnlock: () => void;
}

const PageGate: React.FC<PageGateProps> = ({ onUnlock }) => {
  const [shattering, setShattering] = useState(false);

  const handleShatter = () => {
    setShattering(true);
    setTimeout(onUnlock, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0a0a] flex flex-col items-center justify-center overflow-hidden">
      {!shattering ? (
        <div className="text-center group cursor-pointer" onClick={handleShatter}>
          <div className="mb-8 relative">
            <div className="absolute inset-0 bg-[#ff2d55] blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity"></div>
            <div className="text-8xl md:text-9xl animate-pulse-glow transition-transform group-hover:scale-110">
              🗝️
            </div>
            <div className="absolute -top-4 -left-4 w-full h-full flex items-center justify-center">
               <span className="text-[#ff2d55] text-4xl blur-[1px]">❤️</span>
            </div>
          </div>
          <h1 className="font-playfair text-[#ffd700] text-3xl md:text-5xl tracking-[0.2em] uppercase opacity-80 group-hover:opacity-100">
            Unlock My Heart
          </h1>
          <p className="font-montserrat text-white/40 mt-4 tracking-widest text-sm">FOR ANUHARINE - 2026</p>
        </div>
      ) : (
        <div className="relative w-full h-full flex items-center justify-center">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute bg-[#ff2d55] w-8 h-8 opacity-60"
              style={{
                clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
                animation: `shardFly${i} 1s ease-out forwards`,
              }}
            />
          ))}
          <h2 className="font-playfair text-[#ff2d55] text-6xl animate-pulse">Entering...</h2>
        </div>
      )}

      <style>{`
        ${[...Array(20)].map((_, i) => {
          const x = (Math.random() - 0.5) * 1000;
          const y = (Math.random() - 0.5) * 1000;
          const rotate = Math.random() * 720;
          return `
            @keyframes shardFly${i} {
              0% { transform: translate(0, 0) rotate(0deg) scale(1); opacity: 1; }
              100% { transform: translate(${x}px, ${y}px) rotate(${rotate}deg) scale(0); opacity: 0; }
            }
          `;
        }).join('\n')}
      `}</style>
    </div>
  );
};

export default PageGate;
