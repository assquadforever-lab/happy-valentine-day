
import React, { useState, useEffect } from 'react';

interface Sparkle {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
}

const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [sparkles, setSparkles] = useState<Sparkle[]>([]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      
      if (Math.random() > 0.7) {
        const newSparkle: Sparkle = {
          id: Date.now(),
          x: e.clientX,
          y: e.clientY,
          size: Math.random() * 8 + 2,
          color: Math.random() > 0.5 ? '#ff2d55' : '#bf5af2',
        };
        setSparkles(prev => [...prev.slice(-20), newSparkle]);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <>
      {sparkles.map(s => (
        <div
          key={s.id}
          className="fixed pointer-events-none rounded-full transition-opacity duration-1000"
          style={{
            left: s.x,
            top: s.y,
            width: s.size,
            height: s.size,
            backgroundColor: s.color,
            boxShadow: `0 0 10px ${s.color}`,
            transform: 'translate(-50%, -50%)',
            opacity: 0,
            animation: 'fadeOut 0.8s forwards'
          }}
        />
      ))}
      <div
        className="fixed pointer-events-none z-[9999] text-2xl transition-transform duration-75"
        style={{
          left: position.x,
          top: position.y,
          transform: 'translate(-50%, -50%)',
          filter: 'drop-shadow(0 0 8px #ff2d55)'
        }}
      >
        ❤️
      </div>
      <style>{`
        @keyframes fadeOut {
          0% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
          100% { opacity: 0; transform: translate(-50%, -50%) scale(0.2); }
        }
      `}</style>
    </>
  );
};

export default CustomCursor;
