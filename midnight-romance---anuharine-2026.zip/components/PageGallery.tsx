
import React, { useState, useEffect } from 'react';

const Countdown: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0, hours: 0, minutes: 0, seconds: 0
  });

  useEffect(() => {
    const target = new Date('2026-02-14T00:00:00').getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = target - now;

      if (difference < 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-wrap justify-center gap-6 md:gap-12 py-12 animate-in fade-in zoom-in duration-1000">
      {[
        { label: 'Days', value: timeLeft.days, color: '#ff2d55' },
        { label: 'Hours', value: timeLeft.hours, color: '#bf5af2' },
        { label: 'Minutes', value: timeLeft.minutes, color: '#ffd700' },
        { label: 'Seconds', value: timeLeft.seconds, color: '#00d2ff' }
      ].map((item) => (
        <div key={item.label} className="flex flex-col items-center">
          <div className="relative group">
            <div 
              className="absolute inset-0 blur-[25px] opacity-20 rounded-2xl transition-opacity group-hover:opacity-40" 
              style={{ backgroundColor: item.color }} 
            />
            <div className="glass px-6 py-8 md:px-10 md:py-12 rounded-3xl border-white/10 min-w-[100px] md:min-w-[150px] flex flex-col items-center justify-center relative overflow-hidden">
              <span 
                className="text-4xl md:text-7xl font-bold font-playfair transition-all"
                style={{ color: item.color, textShadow: `0 0 20px ${item.color}44` }}
              >
                {item.value.toString().padStart(2, '0')}
              </span>
              <div className="absolute bottom-0 left-0 w-full h-1 opacity-30" style={{ backgroundColor: item.color }} />
            </div>
          </div>
          <span className="text-xs uppercase tracking-[0.4em] mt-6 text-white/40 font-montserrat">{item.label}</span>
        </div>
      ))}
    </div>
  );
};

const PageGallery: React.FC = () => {
  return (
    <div className="min-h-screen pt-32 px-6 md:px-12 flex flex-col items-center justify-center">
      <div className="text-center mb-4 space-y-4">
        <h1 className="font-playfair text-[#ffd700] text-lg md:text-2xl tracking-[0.5em] uppercase opacity-60">
          The Grand Arrival
        </h1>
        <h2 className="font-playfair text-white text-4xl md:text-8xl mb-4 leading-tight">
          Valentine's <span className="text-[#ff2d55]">2026</span>
        </h2>
        <div className="h-px w-24 bg-[#ff2d55] mx-auto opacity-50" />
      </div>
      
      <p className="font-sacramento text-2xl md:text-4xl text-white/80 mb-8 text-center max-w-2xl">
        Every second brings us closer to a midnight that belongs only to us, Anuharine.
      </p>
      
      <Countdown />

      <div className="mt-16 flex flex-col items-center gap-4 opacity-40 hover:opacity-100 transition-opacity duration-500">
         <div className="w-px h-24 bg-gradient-to-b from-[#ff2d55] to-transparent" />
         <p className="font-montserrat text-[10px] tracking-[0.5em] uppercase">The countdown to forever</p>
      </div>
      
      <div className="pb-32" />
    </div>
  );
};

export default PageGallery;
