
import React, { useState } from 'react';
import { SECRETS } from '../constants';

const PageMap: React.FC = () => {
  const [activeSecret, setActiveSecret] = useState<string | null>(null);

  return (
    <div className="min-h-screen pt-24 relative overflow-hidden flex flex-col items-center">
      <div className="z-10 text-center mb-12">
        <h2 className="font-playfair text-[#bf5af2] text-4xl md:text-6xl mb-4">Our 2026 Universe</h2>
        <p className="font-montserrat text-white/50 tracking-widest text-sm">TAP THE STARS TO REVEAL SECRETS</p>
      </div>

      <div className="relative w-full max-w-5xl aspect-video md:aspect-[21/9] border border-white/5 mx-auto rounded-3xl bg-[#0d0d0d] overflow-hidden">
        {/* Star Field */}
        {[...Array(100)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white opacity-20 animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 3}px`,
              height: `${Math.random() * 3}px`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}

        {/* Secret Stars */}
        {SECRETS.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSecret(s.content)}
            className="absolute z-20 group"
            style={{ top: `${s.y}%`, left: `${s.x}%` }}
          >
            <div className="w-4 h-4 rounded-full bg-[#ffd700] blur-[4px] group-hover:blur-[8px] transition-all" />
            <div className="absolute inset-0 flex items-center justify-center">
               <div className="w-1.5 h-1.5 rounded-full bg-white group-hover:scale-150 transition-transform" />
            </div>
            <div className="absolute -top-1 w-6 h-6 border border-[#ffd700]/40 rounded-full animate-ping" />
          </button>
        ))}

        {/* Secret Display Overlay */}
        {activeSecret && (
          <div 
            className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-30 p-8 cursor-pointer"
            onClick={() => setActiveSecret(null)}
          >
            <div className="text-center max-w-md animate-in fade-in zoom-in duration-300">
              <p className="font-sacramento text-4xl md:text-6xl text-[#ffd700] mb-6 leading-relaxed">
                "{activeSecret}"
              </p>
              <span className="font-montserrat text-white/40 text-xs tracking-widest">TAP ANYWHERE TO CLOSE</span>
            </div>
          </div>
        )}
      </div>
      
      {/* Nebula Decoration */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-[#bf5af2] blur-[150px] opacity-10 rounded-full -z-1" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#ff2d55] blur-[150px] opacity-10 rounded-full -z-1" />
    </div>
  );
};

export default PageMap;
