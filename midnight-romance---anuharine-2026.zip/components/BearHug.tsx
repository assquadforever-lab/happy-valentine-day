
import React from 'react';
import { BearSVG, MochaSVG } from '../constants';

interface BearHugProps {
  active: boolean;
}

const BearHug: React.FC<BearHugProps> = ({ active }) => {
  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      {/* Background Dimming for focus */}
      <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-700 ${active ? 'opacity-100' : 'opacity-0'}`} />

      {/* Boy Bear (Milk) - Boy slides in first slightly */}
      <div 
        className={`absolute top-1/2 -translate-y-1/2 transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)] w-64 md:w-96 ${
          active ? 'left-1/2 -translate-x-[95%] rotate-[8deg]' : 'left-0 -translate-x-full rotate-[-20deg]'
        }`}
        style={{ transitionDelay: active ? '0s' : '0.1s' }}
      >
        <div className="filter drop-shadow(0 0 40px rgba(255,245,230,0.3))">
          <BearSVG className="w-full h-full" />
        </div>
      </div>

      {/* Girl Bear (Mocha) - Girl slides in slightly after */}
      <div 
        className={`absolute top-1/2 -translate-y-1/2 transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)] w-64 md:w-96 ${
          active ? 'right-1/2 translate-x-[95%] rotate-[-8deg]' : 'right-0 translate-x-full rotate-[20deg]'
        }`}
        style={{ transitionDelay: active ? '0.1s' : '0s' }}
      >
        <div className="filter drop-shadow(0 0 40px rgba(139,90,43,0.3))">
          <MochaSVG className="w-full h-full" />
        </div>
      </div>

      {/* Central Heart Explosion */}
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[130%] transition-all duration-500 delay-500 ${active ? 'scale-125 opacity-100' : 'scale-0 opacity-0'}`}>
        <div className="text-7xl md:text-9xl animate-bounce drop-shadow-[0_0_20px_#ff2d55]">💖</div>
        
        {/* Particle Hearts */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute top-1/2 left-1/2 text-3xl animate-ping"
            style={{
              animationDelay: `${i * 0.15}s`,
              transform: `translate(${(i - 3.5) * 45}px, ${(i % 2 ? -40 : 40)}px)`,
              opacity: active ? 0.8 : 0
            }}
          >
            {i % 2 === 0 ? '✨' : '❤️'}
          </div>
        ))}
      </div>

      {/* Message */}
      <div className={`absolute bottom-24 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-400 ${active ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <div className="text-center space-y-2">
          <p className="font-sacramento text-5xl md:text-7xl text-[#ffd700] drop-shadow-[0_0_15px_rgba(255,215,0,0.4)]">
            Warmest Hugs!
          </p>
          <p className="font-montserrat text-[10px] tracking-[0.4em] uppercase text-white/40">
            For my one and only Anuharine
          </p>
        </div>
      </div>

      <style>{`
        @keyframes float-heart {
          0% { transform: translateY(0) scale(1); opacity: 1; }
          100% { transform: translateY(-120px) scale(1.8); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default BearHug;
