
import React from 'react';

export const COLORS = {
  obsidian: '#0a0a0a',
  neonRose: '#ff2d55',
  electricPurple: '#bf5af2',
  gold: '#ffd700',
  milk: '#fff5e6',
  mocha: '#8b5a2b',
};

export const SECRETS = [
  { id: 1, x: 15, y: 25, content: "The way you smile at your coffee..." },
  { id: 2, x: 45, y: 15, content: "Our first midnight drive in 2026." },
  { id: 3, x: 75, y: 35, content: "The song we'll name our first star after." },
  { id: 4, x: 25, y: 65, content: "Your laugh is my favorite frequency." },
  { id: 5, x: 85, y: 75, content: "I promise to always keep the bears glowing for you." },
  { id: 6, x: 55, y: 85, content: "Anuharine + Love = Infinity." },
];

export const COMPLIMENTS = [
  { id: 1, text: "You're more radiant than a supernova.", glowColor: '#ff2d55' },
  { id: 2, text: "Your soul is pure neon magic.", glowColor: '#bf5af2' },
  { id: 3, text: "You make the universe look dim.", glowColor: '#ffd700' },
  { id: 4, text: "I'd follow your light anywhere.", glowColor: '#00d2ff' },
  { id: 5, text: "Simply perfection, Anuharine.", glowColor: '#ff2d55' },
];

// Boy Bear (Milk - Creamy White)
export const BearSVG: React.FC<{ color?: string, className?: string }> = ({ color = '#fff5e6', className }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="55" r="30" fill={color} fillOpacity="0.9" stroke="#333" strokeWidth="1" />
    <circle cx="35" cy="35" r="12" fill={color} fillOpacity="0.9" stroke="#333" strokeWidth="1" />
    <circle cx="65" cy="35" r="12" fill={color} fillOpacity="0.9" stroke="#333" strokeWidth="1" />
    <circle cx="42" cy="50" r="2.5" fill="#333" />
    <circle cx="58" cy="50" r="2.5" fill="#333" />
    <path d="M48 62Q50 64 52 62" stroke="#333" strokeWidth="2" strokeLinecap="round" />
    {/* Small Blue Bow-tie */}
    <path d="M46 68 L54 74 M54 68 L46 74" stroke="#00d2ff" strokeWidth="2" />
  </svg>
);

// Girl Bear (Mocha - Warm Brown with a bow)
export const MochaSVG: React.FC<{ color?: string, className?: string }> = ({ color = '#8b5a2b', className }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="55" r="30" fill={color} fillOpacity="0.9" stroke="#221100" strokeWidth="1" />
    <circle cx="30" cy="30" r="15" fill={color} fillOpacity="0.9" stroke="#221100" strokeWidth="1" />
    <circle cx="70" cy="30" r="15" fill={color} fillOpacity="0.9" stroke="#221100" strokeWidth="1" />
    <circle cx="40" cy="50" r="2.5" fill="#111" />
    <circle cx="60" cy="50" r="2.5" fill="#111" />
    <path d="M47 64Q50 66 53 64" stroke="#111" strokeWidth="2" strokeLinecap="round" />
    {/* Pink Ribbon on ear */}
    <circle cx="30" cy="25" r="5" fill="#ff2d55" />
    <path d="M28 25 L32 25" stroke="white" strokeWidth="1" />
  </svg>
);
