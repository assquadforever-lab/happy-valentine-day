
import React, { useState, useEffect } from 'react';
import CustomCursor from './components/CustomCursor';
import BearHug from './components/BearHug';
import PageGate from './components/PageGate';
import PageGallery from './components/PageGallery';
import PageMap from './components/PageMap';
import PageLetter from './components/PageLetter';
import { AppState } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppState>('GATE');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [hugActive, setHugActive] = useState(false);
  const [musicPlaying, setMusicPlaying] = useState(false);

  // Simple state machine for the flow
  const handleUnlock = () => {
    setIsUnlocked(true);
    setActiveTab('GALLERY');
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white selection:bg-[#ff2d55] selection:text-white overflow-x-hidden">
      <CustomCursor />
      <BearHug active={hugActive} />

      {!isUnlocked ? (
        <PageGate onUnlock={handleUnlock} />
      ) : (
        <>
          {/* Navigation Bar */}
          <nav className="fixed top-0 left-0 w-full z-[60] px-6 py-6 flex justify-between items-center glass border-b border-white/5">
            <div className="font-playfair text-[#ffd700] text-xl md:text-2xl tracking-[0.2em] font-bold">
              ANUHARINE <span className="opacity-40">2026</span>
            </div>
            
            <div className="hidden md:flex gap-12 items-center">
              {(['GALLERY', 'MAP', 'LETTER'] as AppState[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`font-montserrat text-[10px] tracking-[0.4em] uppercase transition-all relative group ${
                    activeTab === tab ? 'text-[#ff2d55]' : 'text-white/40 hover:text-white'
                  }`}
                >
                  {tab === 'GALLERY' ? 'The Countdown' : tab === 'MAP' ? 'The Universe' : 'The Letter'}
                  {activeTab === tab && (
                    <span className="absolute -bottom-2 left-0 w-full h-px bg-[#ff2d55] animate-pulse" />
                  )}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <button 
                onClick={() => setMusicPlaying(!musicPlaying)}
                className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all duration-500 ${
                  musicPlaying ? 'border-[#ff2d55] bg-[#ff2d55]/10 shadow-[0_0_15px_rgba(255,45,85,0.3)]' : 'border-white/10 hover:border-white/30'
                }`}
              >
                {musicPlaying ? '🎵' : '🔇'}
              </button>
            </div>
          </nav>

          {/* Mobile Bottom Nav */}
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 md:hidden z-[60] glass rounded-full px-8 py-4 flex gap-10 items-center border border-white/10 shadow-2xl">
             {(['GALLERY', 'MAP', 'LETTER'] as AppState[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`text-2xl transition-all duration-300 ${activeTab === tab ? 'scale-125 text-[#ff2d55]' : 'opacity-30 grayscale'}`}
                >
                  {tab === 'GALLERY' && '⌛'}
                  {tab === 'MAP' && '🌌'}
                  {tab === 'LETTER' && '📜'}
                </button>
              ))}
          </div>

          {/* Main Content Areas */}
          <main className="transition-opacity duration-1000 animate-in fade-in">
            {activeTab === 'GALLERY' && <PageGallery />}
            {activeTab === 'MAP' && <PageMap />}
            {activeTab === 'LETTER' && <PageLetter />}
          </main>

          {/* Global Bear Hug Trigger */}
          <div className="fixed bottom-12 right-12 z-[110] hidden md:block">
            <button
              onMouseEnter={() => setHugActive(true)}
              onMouseLeave={() => setHugActive(false)}
              className="group relative flex items-center justify-center p-4"
            >
              <div className="absolute inset-0 bg-[#ff2d55] rounded-full blur-xl opacity-20 group-hover:opacity-60 transition-opacity" />
              <div className="relative bg-[#0a0a0a] border border-[#ff2d55]/30 hover:border-[#ff2d55] text-[#ff2d55] w-20 h-20 rounded-full flex flex-col items-center justify-center transition-all duration-500 hover:scale-110">
                 <span className="text-2xl group-hover:scale-125 transition-transform duration-300">🧸</span>
                 <span className="text-[8px] font-bold tracking-tighter mt-1">HUG</span>
              </div>
            </button>
          </div>
        </>
      )}

      {/* Hidden Audio Element */}
      {musicPlaying && (
        <audio autoPlay loop src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" />
      )}
    </div>
  );
};

export default App;
